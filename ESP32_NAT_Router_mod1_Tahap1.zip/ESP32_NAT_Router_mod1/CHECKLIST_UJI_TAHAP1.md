# Checklist Uji Tahap 1 di Hardware

Firmware: v2.4.23-mod.1. Status pengujian saat ini:

| Jenis uji | Status |
|---|---|
| Build ESP-IDF 5.5.4 (target esp32, DIO, 40 MHz, 4 MB) | Lulus, 0 error, 0 warning |
| Isi BIN gabungan dicocokkan byte-per-byte dengan file terpisah di tiap offset | Lulus |
| Uji tombol dashboard di browser Chromium terhadap server tiruan (mock API) | 27/27 lulus |
| Uji di ESP32 asli (WiFi, NAT, client, sensor, sesi, restart) | **BELUM. Perlu lo jalankan di hardware.** |

Uji mock hanya membuktikan tiap tombol memanggil endpoint yang benar, memproses respons, dan menampilkan error. Mock tidak membuktikan firmware berjalan benar di chip. Isi kolom hasil di bawah lalu kirim balik ke gw (termasuk log serial kalau ada).

## 1. Boot dan fungsi lama (paling penting)

| # | Langkah | Yang diharapkan | Hasil |
|---|---|---|---|
| 1.1 | Flash, nyalakan, tunggu 30 detik | AP muncul, tidak boot loop | |
| 1.2 | Log serial (kalau ada) | `App version: 2.4.23-mod.1`, `Last reset reason: Power-on`, `Dashboard at /dash (... bytes gz)` | |
| 1.3 | Buka `http://192.168.4.1/` | Halaman klasik Martin tampil normal | |
| 1.4 | Atur uplink di halaman klasik, simpan & reboot | Terhubung ke router rumah, dapat IP | |
| 1.5 | HP/laptop sebagai client buka beberapa situs + speed test | Internet jalan, kecepatan sebanding firmware asli | |
| 1.6 | Halaman klasik lain (/config, /mappings, /firewall, /scan, /vpn) | Semua tampil dan menyimpan seperti biasa | |
| 1.7 | Biarkan jalan ≥ 1 jam dengan 2+ client | Tidak restart sendiri (cek uptime di /dash) | |

## 2. Dashboard /dash

| # | Langkah | Yang diharapkan | Hasil |
|---|---|---|---|
| 2.1 | Buka `/dash` tanpa password admin | Form "Buat password admin" | |
| 2.2 | Buat password 6–63 karakter | Pindah ke form login | |
| 2.3 | Login salah | Pesan "Password salah" | |
| 2.4 | Login benar | Masuk tab Ringkasan, data uplink/AP terisi | |
| 2.5 | Uptime | Format `00 hari 00 jam 05 menit 14 detik`, berjalan tiap detik | |
| 2.6 | NAT (aktual di lwIP) | `ON` saat mode NAT | |
| 2.7 | Jumlah client | Sama dengan jumlah perangkat yang tersambung | |
| 2.8 | Tab Sistem | RAM, blok terbesar, grafik, CPU core 0/1, tabel task terisi | |
| 2.9 | Tab Log | Ada event Boot, Uplink up, Client join/left | |
| 2.10 | Tombol Muat ulang log | Muncul "Log dimuat" | |
| 2.11 | Logout | Kembali ke login; buka `/api/status` di tab baru → 401 | |
| 2.12 | Login di halaman klasik Martin | Tetap berfungsi dengan password yang sama | |

## 3. Keamanan login

| # | Langkah | Yang diharapkan | Hasil |
|---|---|---|---|
| 3.1 | 5x password salah di /dash | Percobaan ke-6 ditolak "Coba lagi dalam ~60 detik" | |
| 3.2 | Tunggu 60 detik, login benar | Berhasil | |
| 3.3 | 5x salah di halaman klasik | Pesan "Too many failed attempts" | |
| 3.4 | Password lama dari firmware Martin (kalau update dengan setting tetap) | Login berhasil, lalu otomatis dimigrasi ke PBKDF2 | |
| 3.5 | Tab Admin → Ganti password (password lama salah) | Ditolak | |
| 3.6 | Ganti password (benar) | Diminta login ulang, password baru berlaku | |
| 3.7 | Waktu login | Catat kira-kira berapa detik (PBKDF2 10.000 iterasi; perkiraan < 1 detik, belum diukur) | |

## 4. Suhu chip

| # | Langkah | Yang diharapkan | Hasil |
|---|---|---|---|
| 4.1 | Tunggu ≥ 5 menit, lihat tab Sistem → Suhu | Salah satu: angka (status Normal/Peringatan) **atau** "Tidak tersedia" | |
| 4.2 | Catat nilai "Raw sensor" | Kalau tetap 128 terus → sensor memang tidak berfungsi di chip lo (umum di ESP32 klasik) | |
| 4.3 | Ubah batas peringatan (mis. 70) → Simpan | "Batas suhu disimpan", nilai bertahan setelah restart | |

Catatan: angka suhu ini suhu die silikon (tidak terkalibrasi), bukan suhu casing atau ruangan.

## 5. Restart dan alasan reset

| # | Langkah | Yang diharapkan | Hasil |
|---|---|---|---|
| 5.1 | Tab Admin → Restart → OK | Tombol terkunci, router restart, dashboard kembali ke login setelah tersambung ulang | |
| 5.2 | Login lagi | "Restart terakhir: Software: manual (dashboard)" | |
| 5.3 | Simpan setting di halaman klasik (yang memicu reboot) | "Software: classic web UI (save/reboot)" | |
| 5.4 | Cabut-colok daya | "Power-on" | |
| 5.5 | Matikan router rumah sampai watchdog reconnect Martin aktif (kalau diaktifkan) | "Software: reconnect watchdog (no uplink)" | |

## 6. RAM

Catat dari tab Sistem setelah 10 menit dengan 2+ client: RAM bebas ____ KB, minimum sejak boot ____ KB, blok terbesar ____ KB, sisa stack task `esp_timer` ____ B dan `httpd` ____ B.

Tambahan RAM statis Tahap 1 dibanding firmware asli: +5,7 KB DRAM (log 3 KB, sampling task 1,4 KB, histori 0,7 KB, sisanya limiter login), +512 B stack task esp_timer (dinaikkan untuk headroom), IRAM +108 B.
