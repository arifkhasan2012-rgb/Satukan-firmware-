# Panduan Flashing via HP Android + USB OTG

Firmware: **ESP32 NAT Router v2.4.23-mod.1** (Martin v2.4.23 + Tahap 1)
Target: ESP32 klasik (ESP32-D0WD / WROOM-32U), flash 4 MB, mode DIO, 40 MHz.

Semua alamat di bawah diambil langsung dari `flasher_args.json` hasil build, bukan dikarang.

## Isi folder

| File | Alamat flash | Ukuran | Keterangan |
|---|---|---|---|
| `esp32_nat_router_MERGED_0x0.bin` | **0x0** | 1.520.288 B | Satu file gabungan (bootloader + partisi + otadata + app) |
| `terpisah/bootloader.bin` | **0x1000** | 22.736 B | Bootloader ESP-IDF 5.5.4 |
| `terpisah/partition-table.bin` | **0x8000** | 3.072 B | Tabel partisi (identik dengan firmware asli Martin) |
| `terpisah/ota_data_initial.bin` | **0xF000** | 8.192 B | Data OTA: memaksa boot dari slot `ota_0` |
| `terpisah/esp32_nat_router.bin` | **0x20000** | 1.389.216 B | Aplikasi (firmware utama) |

Cek checksum di `SHA256SUMS.txt` kalau file dipindah-pindah antar perangkat.

Setting flash yang dipakai: **Flash mode DIO, Flash freq 40 MHz, Flash size 4 MB**. Chip: **ESP32** (bukan S2/S3/C3).

## Pilih metode yang sesuai

### A. Instalasi pertama / ganti dari firmware lain → pakai file gabungan
- Flash `esp32_nat_router_MERGED_0x0.bin` di alamat **0x0**.
- PENTING: file gabungan mengisi area NVS (0x9000–0xEFFF) dengan 0xFF, jadi **semua setting tersimpan akan terhapus** (SSID uplink, password AP, password admin, port map, dll). Router kembali ke default (AP `ESP32_NAT_Router`, IP 192.168.4.1).
- Partisi `storage` (0x320000) tidak tersentuh.

### B. Update dari firmware Martin / versi mod sebelumnya, setting tetap → file terpisah
Flash hanya dua file ini:
- `ota_data_initial.bin` di **0xF000**
- `esp32_nat_router.bin` di **0x20000**

`ota_data_initial.bin` wajib ikut. Tanpa itu, kalau sebelumnya pernah update via web OTA (firmware aktif di slot `ota_1`), ESP32 akan tetap boot firmware lama di `ota_1` dan file baru di 0x20000 tidak pernah jalan.

Bootloader dan partition table tidak perlu ditulis ulang karena tabel partisinya sama persis (SHA256 identik dengan build asli).

### C. Update tanpa kabel (web OTA bawaan Martin)
Di halaman klasik Martin `http://192.168.4.1/config` → bagian "Firmware Update (OTA)" → Upload Firmware, upload `terpisah/esp32_nat_router.bin`. Setting tetap aman. Fitur rollback ESP-IDF aktif.

### D. Flash keempat file terpisah (setting tetap aman)
Kalau aplikasi flasher mendukung banyak file, isi keempatnya: 0x1000, 0x8000, 0xF000, 0x20000. Cara ini **tidak** menghapus NVS karena area 0x9000 tidak ditulis. Jangan centang opsi "Erase flash" kalau ingin setting tetap ada.

## Langkah di aplikasi Android

Gw tidak menemukan aplikasi dengan nama persis "ESP Flash OTG" di pencarian, jadi langkah di bawah bersifat umum. Nama tombol di aplikasi lo mungkin sedikit berbeda.

1. Salin folder release ini ke HP (mis. ke `Download/`).
2. Aktifkan OTG di HP kalau ada togglenya (Setelan → Koneksi/Fitur tambahan → OTG).
3. Colok ESP32 ke HP: kabel data (bukan kabel charge saja) + adaptor OTG.
4. Buka aplikasi, izinkan akses USB saat muncul pop-up.
5. Pilih chip **ESP32**. Baud rate: mulai **115200** (paling aman di OTG). Kalau stabil, boleh coba 460800.
6. Pilih file dan alamat sesuai metode A, B, atau D di atas. Ketik alamat persis seperti tertulis (0x0, 0x1000, 0x8000, 0xF000, 0x20000).
7. Kalau ada pilihan flash mode/frekuensi/ukuran: **DIO / 40 MHz / 4 MB**, atau biarkan "keep / detect".
8. Mulai flash. Kalau koneksi gagal ("Failed to connect", "Timed out waiting for packet header"):
   - Tahan tombol **BOOT** (IO0), tekan-lepas **EN/RST**, lalu lepas BOOT, kemudian coba lagi.
   - Board ESP32-WROOM-32U "basic" tanpa rangkaian auto-reset wajib pakai cara ini.
9. Di log, pastikan muncul kira-kira `Chip is ESP32-D0WD...` dan ukuran flash terdeteksi `4MB`. Kalau terdeteksi chip lain, hentikan.
10. Setelah selesai, tekan **EN/RST** sekali (kalau aplikasi tidak reset otomatis).

## Setelah boot pertama

1. Sambungkan HP ke WiFi `ESP32_NAT_Router` (atau SSID AP lo kalau setting masih ada).
2. Buka `http://192.168.4.1/dash` → buat password admin (6–63 karakter).
3. Halaman klasik Martin tetap ada di `http://192.168.4.1/`.
4. Kalau punya kabel serial ke PC, log boot harus menampilkan `App version: 2.4.23-mod.1` dan `Last reset reason: ...`.

## Kalau ada masalah

- **Boot loop / tidak muncul AP**: flash ulang file gabungan di 0x0 (metode A). Kalau tetap gagal, kembali ke firmware asli Martin dengan cara yang sama.
- **Lupa password admin**: via console serial `set_router_password <baru>`, atau factory reset: tahan tombol BOOT 5 detik selama firmware berjalan (LED berkedip cepat), router lalu restart dengan setting default (fitur asli Martin).
- **Balik ke firmware Martin setelah password dimigrasi**: firmware asli tidak bisa membaca format hash baru (PBKDF2). Setel ulang password lewat serial atau factory reset.
